import React from 'react'

export default function Contact() {
  return (
    <div>
        <h4>I am in Contact page</h4>
    </div>
  )
}

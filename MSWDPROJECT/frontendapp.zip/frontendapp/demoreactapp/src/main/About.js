import React from 'react'

export default function About() {
  return (
    <div>
        <h4>I am in About page</h4>
    </div>
  )
}
